import sys
import configparser
from datetime import datetime
from pytz import timezone

import mysql.connector
from mysql.connector import Error

from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QListWidget, QLineEdit, QGroupBox,
    QRadioButton, QScrollArea, QMessageBox, QCheckBox, QSizePolicy
)
from PyQt6.QtGui import QPixmap, QFont, QIcon
from PyQt6.QtCore import Qt


# --- Leitura config.ini ---
config = configparser.ConfigParser()
config.read("config.ini")

DB_HOST = config.get("database", "DB_HOST", fallback="localhost")
DB_USER = config.get("database", "DB_USER", fallback="root")
DB_PASSWORD = config.get("database", "DB_PASSWORD", fallback="")
DB_NAME = config.get("database", "DB_NAME", fallback="almoxarifado")
DB_PORT = config.getint("database", "DB_PORT", fallback=3306)


class EmprestimoItem(QWidget):
    def __init__(self, emprestimo_id, nome_componente, quantidade, data_emp, data_dev, status):
        super().__init__()
        self.emprestimo_id = emprestimo_id
        self.status = status

        layout = QHBoxLayout()
        layout.setContentsMargins(5, 2, 5, 2)
        layout.setSpacing(10)

        self.checkbox = QCheckBox()
        layout.addWidget(self.checkbox)

        label_text = (
            f"<b>{nome_componente}</b> | Qtde: {quantidade} | "
            f"Retirada: {data_emp} | Devolução: {data_dev} | "
            f"Status: {status}"
        )
        self.label = QLabel(label_text)
        self.label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        layout.addWidget(self.label)

        self.setLayout(layout)


class AlmoxarifadoApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sistema de Almoxarifado")
        # Define o ícone se existir (opcional)
        try:
            self.setWindowIcon(QIcon("app_icon.ico"))
        except Exception:
            pass

        self.setGeometry(100, 100, 1100, 700)

        self.dark_mode = False  # Pode ativar depois se quiser
        self.matricula_selecionada = None
        self.emprestimo_items = []

        self.init_ui()

    def init_ui(self):
        main_layout = QVBoxLayout()
        self.setLayout(main_layout)

        self.criar_grupo_detalhes()
        self.criar_grupo_pesquisa()
        self.criar_grupo_pesquisa_componente()
        self.criar_grupo_emprestimos()

        main_layout.addWidget(self.group_detalhes)
        main_layout.addWidget(self.group_pesquisa)
        main_layout.addWidget(self.group_pesquisa_componente)
        main_layout.addWidget(self.group_emprestimos)

    def criar_grupo_detalhes(self):
        self.group_detalhes = QGroupBox("Detalhes do Aluno")
        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        top_layout = QHBoxLayout()

        self.foto_label = QLabel()
        self.foto_label.setPixmap(QPixmap("default.png").scaled(80, 80))
        self.foto_label.setFixedSize(80, 80)
        self.foto_label.setStyleSheet("border: 1px solid #D6DBE0; border-radius: 3px;")
        top_layout.addWidget(self.foto_label)

        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)

        self.label_matricula = QLabel("Matrícula: -")
        self.label_nome = QLabel("Nome: -")
        self.label_email = QLabel("E-mail: -")
        self.label_turma = QLabel("Turma: -")

        for label in [self.label_matricula, self.label_nome, self.label_email, self.label_turma]:
            label.setFont(QFont("Arial", 9))

        info_layout.addWidget(self.label_matricula)
        info_layout.addWidget(self.label_nome)
        info_layout.addWidget(self.label_email)
        info_layout.addWidget(self.label_turma)

        top_layout.addLayout(info_layout)
        layout.addLayout(top_layout)

        status_layout = QHBoxLayout()
        status_layout.addWidget(QLabel("Status de Empréstimos:"))
        self.status_label = QLabel("Nenhum empréstimo")
        self.status_label.setFont(QFont("Arial", 9, QFont.Weight.Bold))
        status_layout.addWidget(self.status_label)
        status_layout.addStretch()
        layout.addLayout(status_layout)

        self.group_detalhes.setLayout(layout)

    def criar_grupo_pesquisa(self):
        self.group_pesquisa = QGroupBox("Pesquisar Aluno")
        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        search_layout = QHBoxLayout()
        self.pesquisa_input = QLineEdit()
        self.pesquisa_input.setPlaceholderText("Digite matrícula ou nome")
        self.pesquisa_input.setClearButtonEnabled(True)
        self.pesquisa_input.returnPressed.connect(self.pesquisar_aluno)
        search_layout.addWidget(self.pesquisa_input)

        self.botao_pesquisa = QPushButton("Buscar")
        self.botao_pesquisa.setFixedWidth(80)
        self.botao_pesquisa.clicked.connect(self.pesquisar_aluno)
        search_layout.addWidget(self.botao_pesquisa)

        layout.addLayout(search_layout)

        self.lista_alunos = QListWidget()
        self.lista_alunos.setMinimumHeight(150)
        self.lista_alunos.itemClicked.connect(self.mostrar_detalhes_aluno)
        layout.addWidget(self.lista_alunos)

        self.group_pesquisa.setLayout(layout)

    def criar_grupo_pesquisa_componente(self):
        self.group_pesquisa_componente = QGroupBox("Pesquisar Componente")
        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        search_layout = QHBoxLayout()
        self.pesquisa_componente_input = QLineEdit()
        self.pesquisa_componente_input.setPlaceholderText("Digite nome ou código do componente")
        self.pesquisa_componente_input.setClearButtonEnabled(True)
        self.pesquisa_componente_input.returnPressed.connect(self.pesquisar_componente)
        search_layout.addWidget(self.pesquisa_componente_input)

        self.botao_pesquisa_componente = QPushButton("Buscar")
        self.botao_pesquisa_componente.setFixedWidth(80)
        self.botao_pesquisa_componente.clicked.connect(self.pesquisar_componente)
        search_layout.addWidget(self.botao_pesquisa_componente)

        layout.addLayout(search_layout)

        tipo_layout = QHBoxLayout()
        self.radio_nome = QRadioButton("Por Nome")
        self.radio_nome.setChecked(True)
        self.radio_codigo = QRadioButton("Por Código")
        tipo_layout.addWidget(self.radio_nome)
        tipo_layout.addWidget(self.radio_codigo)
        tipo_layout.addStretch()
        layout.addLayout(tipo_layout)

        self.lista_componentes = QListWidget()
        self.lista_componentes.setMinimumHeight(150)
        self.lista_componentes.itemDoubleClicked.connect(self.selecionar_componente)
        layout.addWidget(self.lista_componentes)

        self.group_pesquisa_componente.setLayout(layout)

    def criar_grupo_emprestimos(self):
        self.group_emprestimos = QGroupBox("Gerenciar Empréstimos")
        layout = QVBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(10)

        form_layout = QGridLayout()
        form_layout.setColumnStretch(0, 1)
        form_layout.setColumnStretch(1, 1)
        form_layout.setColumnStretch(2, 0)

        form_layout.addWidget(QLabel("Componente:"), 0, 0)
        self.input_componente = QLineEdit()
        self.input_componente.setPlaceholderText("ID ou nome do componente")
        form_layout.addWidget(self.input_componente, 0, 1)

        form_layout.addWidget(QLabel("Quantidade:"), 1, 0)
        self.input_quantidade = QLineEdit()
        self.input_quantidade.setPlaceholderText("Quantidade")
        form_layout.addWidget(self.input_quantidade, 1, 1)

        self.botao_adicionar = QPushButton("Adicionar")
        self.botao_adicionar.setFixedWidth(100)
        self.botao_adicionar.clicked.connect(self.adicionar_emprestimo)
        form_layout.addWidget(self.botao_adicionar, 0, 2, 2, 1)

        layout.addLayout(form_layout)

        layout.addWidget(QLabel("Empréstimos Ativos:"))

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.scroll_layout.setSpacing(8)
        self.scroll_area.setWidget(self.scroll_content)
        self.scroll_area.setMinimumHeight(250)

        layout.addWidget(self.scroll_area)

        button_layout = QHBoxLayout()
        button_layout.addStretch()

        self.botao_devolver = QPushButton("Registrar Devolução")
        self.botao_devolver.setFixedWidth(150)
        self.botao_devolver.clicked.connect(self.registrar_devolucao)
        button_layout.addWidget(self.botao_devolver)

        layout.addLayout(button_layout)

        self.group_emprestimos.setLayout(layout)

    def pesquisar_aluno(self):
        termo = self.pesquisa_input.text().strip()
        if not termo:
            QMessageBox.warning(self, "Campo Vazio", "Digite um termo para pesquisa")
            return

        self.lista_alunos.clear()

        try:
            conn = mysql.connector.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASSWORD,
                database=DB_NAME, port=DB_PORT
            )
            cursor = conn.cursor()

            cursor.execute(
                "SELECT matricula, nome FROM alunos "
                "WHERE matricula LIKE %s OR nome LIKE %s "
                "LIMIT 50",
                (f"%{termo}%", f"%{termo}%")
            )
            resultados = cursor.fetchall()

            if resultados:
                for mat, nome in resultados:
                    self.lista_alunos.addItem(f"{mat} - {nome}")
            else:
                self.lista_alunos.addItem("Nenhum aluno encontrado.")

            cursor.close()
            conn.close()
        except Error as e:
            QMessageBox.critical(self, "Erro", f"Erro na pesquisa: {str(e)}")

    def mostrar_detalhes_aluno(self, item):
        text = item.text()
        if " - " not in text:
            return

        matricula = text.split(" - ")[0]
        self.matricula_selecionada = matricula

        try:
            conn = mysql.connector.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASSWORD,
                database=DB_NAME, port=DB_PORT
            )
            cursor = conn.cursor()

            cursor.execute(
                "SELECT nome, email, turma, foto "
                "FROM alunos WHERE matricula = %s",
                (matricula,)
            )
            aluno = cursor.fetchone()

            if aluno:
                nome, email, turma, foto_bytes = aluno
                self.label_matricula.setText(f"Matrícula: {matricula}")
                self.label_nome.setText(f"Nome: {nome}")
                self.label_email.setText(f"E-mail: {email}")
                self.label_turma.setText(f"Turma: {turma}")

                if foto_bytes:
                    pixmap = QPixmap()
                    pixmap.loadFromData(foto_bytes)
                else:
                    pixmap = QPixmap("default.png")

                self.foto_label.setPixmap(
                    pixmap.scaled(
                        self.foto_label.width(),
                        self.foto_label.height(),
                        Qt.AspectRatioMode.KeepAspectRatio
                    )
                )

                self.carregar_emprestimos(matricula)

            cursor.close()
            conn.close()
        except Error as e:
            QMessageBox.critical(self, "Erro", f"Erro ao buscar aluno: {str(e)}")

    def pesquisar_componente(self):
        termo = self.pesquisa_componente_input.text().strip()
        if not termo:
            QMessageBox.warning(self, "Campo Vazio", "Digite um termo para pesquisa")
            return

        self.lista_componentes.clear()

        try:
            conn = mysql.connector.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASSWORD,
                database=DB_NAME, port=DB_PORT
            )
            cursor = conn.cursor()

            if self.radio_nome.isChecked():
                cursor.execute(
                    "SELECT id, nome FROM componentes WHERE nome LIKE %s LIMIT 50",
                    (f"%{termo}%",)
                )
            else:
                if not termo.isdigit():
                    QMessageBox.warning(self, "Código Inválido", "O código deve ser um número")
                    return
                cursor.execute(
                    "SELECT id, nome FROM componentes WHERE id = %s",
                    (int(termo),)
                )

            resultados = cursor.fetchall()

            if resultados:
                for cid, nome in resultados:
                    self.lista_componentes.addItem(f"{cid} - {nome}")
            else:
                self.lista_componentes.addItem("Nenhum componente encontrado.")

            cursor.close()
            conn.close()
        except Error as e:
            QMessageBox.critical(self, "Erro", f"Erro na pesquisa: {str(e)}")

    def selecionar_componente(self, item):
        texto = item.text()
        if " - " not in texto:
            return

        id_comp = texto.split(" - ")[0]
        self.input_componente.setText(id_comp)
        self.input_quantidade.setFocus()

    def carregar_emprestimos(self, matricula):
        # Limpa itens antigos
        for i in reversed(range(self.scroll_layout.count())):
            widget = self.scroll_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        total_emprestimos = 0
        self.emprestimo_items = []

        try:
            conn = mysql.connector.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASSWORD,
                database=DB_NAME, port=DB_PORT
            )
            cursor = conn.cursor()

            cursor.execute(
                """SELECT e.id, e.quantidade, c.nome,
                   e.data_emp, e.data_dev, e.status
                   FROM emprestimos e
                   JOIN alunos a ON e.aluno_id = a.id
                   JOIN componentes c ON e.componente_id = c.id
                   WHERE a.matricula = %s
                   ORDER BY e.data_emp DESC""",
                (matricula,)
            )

            registros = cursor.fetchall()
            for (id_emprestimo, qtd, nome, data_emp, data_dev, status) in registros:
                data_emp_str = data_emp.strftime("%d/%m/%Y %H:%M") if data_emp else "---"
                data_dev_str = data_dev.strftime("%d/%m/%Y %H:%M") if data_dev else "---"

                item = EmprestimoItem(
                    id_emprestimo, nome, qtd, data_emp_str, data_dev_str, status
                )
                self.scroll_layout.addWidget(item)
                self.emprestimo_items.append(item)

                if status == 'Emprestado':
                    total_emprestimos += int(qtd)

            self.atualizar_cor_fundo(total_emprestimos)

            if total_emprestimos == 0:
                self.status_label.setText("Nenhum empréstimo ativo")
            elif total_emprestimos < 10:
                self.status_label.setText("Empréstimos sob controle")
            elif total_emprestimos < 15:
                self.status_label.setText("Atenção: Muitos empréstimos")
            else:
                self.status_label.setText("ALERTA: Limite excedido!")

            cursor.close()
            conn.close()
        except Error as e:
            QMessageBox.critical(self, "Erro", f"Erro ao carregar empréstimos: {str(e)}")

    def atualizar_cor_fundo(self, total_emprestimos):
        if self.dark_mode:
            if total_emprestimos == 0:
                cor = "#3C3C3C"
            elif total_emprestimos < 10:
                cor = "#006400"
            elif total_emprestimos < 15:
                cor = "#8B8000"
            else:
                cor = "#8B0000"
        else:
            if total_emprestimos == 0:
                cor = "#FFFFFF"
            elif total_emprestimos < 10:
                cor = "#90EE90"
            elif total_emprestimos < 15:
                cor = "#FFFFE0"
            else:
                cor = "#FFCCCB"

        self.group_detalhes.setStyleSheet(f"""
            QGroupBox {{
                background-color: {cor};
                border: 1px solid #D6DBE0;
                border-radius: 5px;
            }}
        """)

    def adicionar_emprestimo(self):
        if not self.matricula_selecionada:
            QMessageBox.warning(self, "Aluno Não Selecionado", "Selecione um aluno antes de adicionar empréstimos.")
            return

        comp = self.input_componente.text().strip()
        qtd = self.input_quantidade.text().strip()

        if not comp:
            QMessageBox.warning(self, "Componente Ausente", "Informe o componente.")
            return

        if not qtd.isdigit() or int(qtd) <= 0:
            QMessageBox.warning(self, "Quantidade Inválida", "Digite um número positivo para quantidade.")
            return

        try:
            conn = mysql.connector.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASSWORD,
                database=DB_NAME, port=DB_PORT
            )
            cursor = conn.cursor()

            # Verifica o componente (pode ser pelo ID ou nome)
            if comp.isdigit():
                cursor.execute("SELECT id FROM componentes WHERE id = %s", (int(comp),))
            else:
                cursor.execute("SELECT id FROM componentes WHERE nome = %s", (comp,))

            res = cursor.fetchone()
            if not res:
                QMessageBox.warning(self, "Componente não encontrado", "Componente inválido ou não existe.")
                cursor.close()
                conn.close()
                return

            componente_id = res[0]

            # Pega o aluno_id pela matricula
            cursor.execute("SELECT id FROM alunos WHERE matricula = %s", (self.matricula_selecionada,))
            aluno_id = cursor.fetchone()
            if not aluno_id:
                QMessageBox.warning(self, "Aluno não encontrado", "Erro ao localizar aluno no banco.")
                cursor.close()
                conn.close()
                return
            aluno_id = aluno_id[0]

            # Inserir empréstimo com status 'Emprestado' e data atual com timezone Brasil
            tz = timezone('America/Sao_Paulo')
            agora = datetime.now(tz)

            cursor.execute(
                "INSERT INTO emprestimos (aluno_id, componente_id, quantidade, data_emp, status) "
                "VALUES (%s, %s, %s, %s, 'Emprestado')",
                (aluno_id, componente_id, int(qtd), agora)
            )
            conn.commit()
            cursor.close()
            conn.close()

            self.input_componente.clear()
            self.input_quantidade.clear()
            self.pesquisar_aluno()  # Atualiza lista alunos para recarregar
            self.carregar_emprestimos(self.matricula_selecionada)
        except Error as e:
            QMessageBox.critical(self, "Erro", f"Erro ao adicionar empréstimo: {str(e)}")

    def registrar_devolucao(self):
        if not self.emprestimo_items:
            QMessageBox.information(self, "Nada para devolver", "Não há empréstimos para devolver.")
            return

        try:
            conn = mysql.connector.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASSWORD,
                database=DB_NAME, port=DB_PORT
            )
            cursor = conn.cursor()

            tz = timezone('America/Sao_Paulo')
            agora = datetime.now(tz)

            devolvidos = 0
            for item in self.emprestimo_items:
                if item.checkbox.isChecked() and item.status == 'Emprestado':
                    cursor.execute(
                        "UPDATE emprestimos SET status='Devolvido', data_dev=%s WHERE id = %s",
                        (agora, item.emprestimo_id)
                    )
                    devolvidos += 1

            if devolvidos == 0:
                QMessageBox.information(self, "Nenhum selecionado", "Nenhum empréstimo selecionado para devolução.")
                cursor.close()
                conn.close()
                return

            conn.commit()
            cursor.close()
            conn.close()

            QMessageBox.information(self, "Sucesso", f"{devolvidos} devolução(ões) registrada(s).")
            self.carregar_emprestimos(self.matricula_selecionada)
        except Error as e:
            QMessageBox.critical(self, "Erro", f"Erro ao registrar devolução: {str(e)}")


def main():
    app = QApplication(sys.argv)
    window = AlmoxarifadoApp()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
