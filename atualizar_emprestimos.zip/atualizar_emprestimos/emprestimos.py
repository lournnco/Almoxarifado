import csv  # Biblioteca para ler arquivos CSV
import mysql.connector  # Conector para MySQL
from mysql.connector import Error  # Classe para tratar erros específicos do MySQL
from datetime import datetime  # Para converter strings em objetos de data/hora

# Função principal que importa os dados do CSV para a tabela 'emprestimos'
def importar_emprestimos(caminho_csv):
    try:
        # Conecta ao banco de dados MySQL
        conexao = mysql.connector.connect(
            host='localhost',
            user='seu_usuario',         # ← Substituir pelo usuário real
            password='sua_senha',       # ← Substituir pela senha real
            database='almox'            # ← Nome do banco de dados
        )
        cursor = conexao.cursor()

        # Abre o arquivo CSV para leitura
        with open(caminho_csv, 'r', newline='', encoding='utf-8') as arquivo_csv:
            leitor = csv.DictReader(arquivo_csv)  # Lê cada linha como um dicionário
            
            total = 0       # Total de registros processados
            sucessos = 0    # Contador de registros inseridos com sucesso
            erros = 0       # Contador de erros

            # Loop por cada linha do CSV
            for linha in leitor:
                total += 1
                try:
                    matricula = linha['matricula'].strip()  # Remove espaços extras
                    componente_id = int(linha['material'])  # ID do componente
                    data_emp = linha['data_retirada'].strip()  # Data de retirada
                    
                    # Trata a data de devolução (pode estar vazia)
                    data_dev_str = linha.get('data_devolucao', '').strip()

                    # Busca o ID do aluno pela matrícula
                    cursor.execute("SELECT id FROM alunos WHERE matricula = %s", (matricula,))
                    resultado = cursor.fetchone()
                    if not resultado:
                        print(f"❌ Matrícula não encontrada: {matricula}")
                        erros += 1
                        continue
                    aluno_id = resultado[0]

                    # Define o status com base na presença da data de devolução
                    status = 'devolvido' if data_dev_str else 'emprestado'

                    # Converte as datas para o formato datetime
                    data_emp = datetime.strptime(data_emp, '%Y-%m-%d %H:%M:%S')
                    data_dev = datetime.strptime(data_dev_str, '%Y-%m-%d %H:%M:%S') if data_dev_str else None

                    # Insere o registro na tabela 'emprestimos'
                    cursor.execute("""
                        INSERT INTO emprestimos (aluno_id, componente_id, data_emp, data_devolucao, status)
                        VALUES (%s, %s, %s, %s, %s)
                    """, (aluno_id, componente_id, data_emp, data_dev, status))

                    sucessos += 1  # Incrementa contador de sucesso

                except Exception as e:
                    print(f"❌ Erro na linha {total}: {e}")
                    erros += 1
                    continue

        conexao.commit()  # Confirma todas as inserções no banco
        print(f"✅ Importação concluída: {sucessos} sucessos, {erros} erros de {total} registros")

    except Error as erro:
        print(f"❌ Erro no banco de dados: {erro}")
        conexao.rollback()  # Desfaz alterações em caso de erro grave

    except FileNotFoundError:
        print(f"❌ Arquivo não encontrado: {caminho_csv}")

    except Exception as e:
        print(f"❌ Erro inesperado: {e}")

    finally:
        # Fecha o cursor e a conexão com segurança
        if 'cursor' in locals() and cursor:
            cursor.close()
        if 'conexao' in locals() and conexao.is_connected():
            conexao.close()

# Execução direta do script (modo standalone)
if __name__ == "__main__":
    importar_emprestimos('emprestimos.csv')  # ← Ajustar o caminho do arquivo conforme necessário
