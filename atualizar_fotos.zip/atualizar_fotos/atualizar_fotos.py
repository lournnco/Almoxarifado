import mysql.connector
import requests
from mysql.connector import Error
import logging
from pathlib import Path
import sys

# 📋 CONFIGURAÇÃO DO SISTEMA DE LOGS
def setup_logging():
    """
    Configura o sistema de logging para registrar em arquivo e console
    """
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("atualizacao_fotos.log", encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    return logging.getLogger(__name__)

# 🛡️ FUNÇÃO DE VALIDAÇÃO DE IMAGEM
def is_valid_image(content):
    """
    Verifica se o conteúdo é uma imagem válida:
    - Tamanho mínimo de 1KB
    - Assinatura mágica de formatos conhecidos
    - Não começa com HTML ou mensagens de erro
    """
    if len(content) < 1024:
        return False

    image_signatures = {
        b'\xff\xd8\xff': 'JPEG',
        b'\x89PNG\r\n\x1a\n': 'PNG',
        b'GIF8': 'GIF',
        b'BM': 'BMP'
    }

    for signature in image_signatures:
        if content.startswith(signature):
            return True

    invalid_starts = [b'<html', b'<!DOCTYPE', b'HTTP', b'Error', b'Not Found']
    for invalid in invalid_starts:
        if content.startswith(invalid):
            return False

    return True

# 🚀 FUNÇÃO PRINCIPAL
def atualizar_fotos_alunos():
    """
    Atualiza a coluna 'fotos' da tabela 'alunos' com imagens da intranet
    usando o campo 'id' como chave única
    """
    try:
        # 🔌 Conexão com o banco de dados MySQL
        logger.info("🔌 Conectando ao banco de dados MySQL...")
        conn = mysql.connector.connect(
            host='10.233.43.215',
            user='troadmin',
            password='eleTROn1c_flop3#W!w',
            database='site_eletronicaX',
            charset='utf8mb4',
            connection_timeout=30
        )

        if not conn.is_connected():
            logger.error("❌ Falha na conexão com o MySQL")
            return False

        logger.info("✅ Conexão com MySQL estabelecida com sucesso!")

        # 🌐 URL base da intranet onde estão as imagens
        url_base = 'https://intranet.liberato.com.br/tro/data/fotos/'  # Ajuste conforme sua rede

        # 📝 Cria arquivo de falhas se não existir
        Path('falhas.txt').touch(exist_ok=True)
        logger.info("📁 Arquivo de falhas preparado: falhas.txt")

        with conn.cursor(buffered=True) as cursor:
            # 🔍 Busca todos os alunos com id e matrícula
            logger.info("🔍 Buscando registros de alunos...")
            cursor.execute('SELECT id, matricula FROM alunos')
            registros = cursor.fetchall()

            total = len(registros)
            sucessos = 0
            falhas = 0
            pulados = 0

            logger.info(f"🎯 Iniciando processamento de {total} alunos...")

            # 🔁 Loop por cada aluno
            for i, (id_aluno, matricula) in enumerate(registros, 1):
                extensoes = ['.jpeg', '.jpg', '.png', '.gif']
                imagem_encontrada = False

                # ⏭️ Verifica se já existe imagem cadastrada
                cursor.execute('SELECT fotos FROM alunos WHERE id = %s', (id_aluno,))
                resultado = cursor.fetchone()

                if resultado and resultado[0] is not None:
                    pulados += 1
                    if i % 100 == 0:
                        logger.info(f'📊 [{i}/{total}] ⏭️ Pulados={pulados}, ✅ Sucessos={sucessos}, ❌ Falhas={falhas}')
                    continue

                # 🔎 Tenta baixar imagem com diferentes extensões
                for extensao in extensoes:
                    nome_arquivo = f'C{matricula}{extensao}'
                    url_imagem = f'{url_base}/{nome_arquivo}'

                    try:
                        response = requests.get(url_imagem, timeout=10, stream=True)
                        if response.status_code == 200:
                            content = response.content
                            if is_valid_image(content):
                                cursor.execute(
                                    'UPDATE alunos SET fotos = %s WHERE id = %s',
                                    (content, id_aluno)
                                )
                                imagem_encontrada = True
                                sucessos += 1
                                logger.info(f'✅ [{i}/{total}] ID {id_aluno} atualizado - {len(content):,} bytes')
                                break
                            else:
                                logger.debug(f'🖼️ [{i}/{total}] Imagem inválida: {url_imagem}')
                        else:
                            logger.debug(f'🌐 [{i}/{total}] HTTP {response.status_code}: {url_imagem}')
                    except requests.exceptions.Timeout:
                        logger.warning(f'⏱️ [{i}/{total}] Timeout acessando: {url_imagem}')
                        continue
                    except requests.exceptions.ConnectionError:
                        logger.warning(f'🔌 [{i}/{total}] Erro de conexão: {url_imagem}')
                        continue
                    except requests.exceptions.RequestException as e:
                        logger.debug(f'🌐 [{i}/{total}] Erro de rede: {url_imagem} - {e}')
                        continue

                # ❌ Registra falha se nenhuma imagem foi encontrada
                if not imagem_encontrada:
                    falhas += 1
                    with open('falhas.txt', 'a', encoding='utf-8') as f:
                        f.write(f'{id_aluno},{matricula}\n')
                    logger.warning(f'❌ [{i}/{total}] Sem imagem para ID {id_aluno} (Mat: {matricula})')

                # 📈 Log de progresso a cada 50 registros
                if i % 50 == 0:
                    progresso = (i / total) * 100
                    logger.info(f'📈 Progresso: {i}/{total} ({progresso:.1f}%)')

            # 💾 Confirma todas as alterações no banco
            conn.commit()

            # 📊 Relatório final
            taxa_sucesso = (sucessos / (total - pulados)) * 100 if (total - pulados) > 0 else 0
            logger.info(f"""
📊 RESUMO FINAL:
   👥 Total de alunos: {total}
   ✅ Fotos atualizadas: {sucessos}
   ⏭️ Registros pulados: {pulados}
   ❌ Falhas: {falhas}
   📈 Taxa de sucesso: {taxa_sucesso:.1f}%
            """)

    except Error as e:
        logger.error(f"❌ Erro de banco de dados: {e}")
        return False
    except Exception as e:
        logger.error(f"❌ Erro inesperado: {e}")
        return False
    finally:
        if 'conn' in locals() and conn.is_connected():
            conn.close()
            logger.info("🔌 Conexão com MySQL encerrada com sucesso")

    return True

# 🎯 Execução principal
if __name__ == "__main__":
    logger = setup_logging()
    logger.info("🚀 INICIANDO PROCESSO DE ATUALIZAÇÃO DE FOTOS")
    logger.info("=" * 50)

    try:
        if atualizar_fotos_alunos():
            logger.info("🎉 PROCESSAMENTO CONCLUÍDO COM SUCESSO!")
            print("✅ Processamento concluído com sucesso!")
            sys.exit(0)
        else:
            logger.error("💥 OCORRERAM ERROS DURANTE O PROCESSAMENTO")
            print("❌ Ocorreram erros durante o processamento.")
            sys.exit(1)
    except KeyboardInterrupt:
        logger.info("⏹️ Processo interrompido pelo usuário")
        print("⏹️ Processo interrompido pelo usuário")
        sys.exit(1)
    except Exception as e:
        logger.error(f"💥 Erro crítico: {e}")
        print(f"❌ Erro crítico: {e}")
        sys.exit(1)
