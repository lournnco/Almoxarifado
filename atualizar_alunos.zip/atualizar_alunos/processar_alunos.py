import pandas as pd
import os
import glob

def processar_alunos():
    try:
        # 🔍 Busca o arquivo CSV mais recente com prefixo 'alunos'
        arquivos = glob.glob('alunos*.csv')
        if not arquivos:
            print("❌ Nenhum arquivo 'alunos*.csv' encontrado.")
            return False

        arquivo_mais_recente = max(arquivos, key=os.path.getmtime)
        print(f"📂 Arquivo selecionado: {arquivo_mais_recente}")

        # 📥 Tenta diferentes encodings
        try:
            df = pd.read_csv(arquivo_mais_recente, encoding='utf-8')
        except UnicodeDecodeError:
            df = pd.read_csv(arquivo_mais_recente, encoding='latin-1')
            print("⚠️ Usando encoding latin-1")

        # ✅ Verifica e cria campos obrigatórios
        campos_necessarios = ['id', 'matricula', 'nome', 'turma']
        for campo in campos_necessarios:
            if campo not in df.columns:
                if campo == 'id':
                    df['id'] = range(1, len(df) + 1)
                else:
                    df[campo] = ''

        df_alunos = df[campos_necessarios].copy()

        # 📧 Cria campo de e-mail institucional
        df_alunos['email'] = df_alunos['matricula'].astype(str) + '@liberato.com.br'

        # 🔢 Converte turma para numérico para comparação
        df_alunos['turma_num'] = pd.to_numeric(df_alunos['turma'], errors='coerce')

        # 🧠 Agrupa por matrícula e mantém a turma mais alta
        df_alunos.sort_values(by=['matricula', 'turma_num'], ascending=[True, False], inplace=True)
        df_alunos = df_alunos.drop_duplicates(subset='matricula', keep='first')

        # 🧹 Remove campo auxiliar
        df_alunos.drop(columns=['turma_num'], inplace=True)

        # 🔍 Verifica duplicatas
        duplicatas_matricula = df_alunos['matricula'].duplicated().sum()
        duplicatas_nome = df_alunos['nome'].duplicated().sum()

        if duplicatas_matricula > 0 or duplicatas_nome > 0:
            print(f"⚠️ Atenção: {duplicatas_matricula} matrículas e {duplicatas_nome} nomes duplicados.")
        else:
            print("✅ Nenhuma duplicata de matrícula ou nome encontrada.")

        # 💾 Exporta para CSV compatível com Banco 2
        df_alunos.to_csv('alunos_banco2.csv', index=False, encoding='utf-8')
        print("✅ 'alunos_banco2.csv' gerado com sucesso!")

        # 👀 Preview
        print("\n📋 Primeiras 5 linhas:")
        print(df_alunos.head())

        return True

    except Exception as e:
        print(f"❌ Erro inesperado: {e}")
        return False

if __name__ == "__main__":
    processar_alunos()
